﻿namespace racetest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.grayhound1PictureBox = new System.Windows.Forms.PictureBox();
            this.grayhound2PictureBox = new System.Windows.Forms.PictureBox();
            this.grayhound3PictureBox = new System.Windows.Forms.PictureBox();
            this.grayhound4PictureBox = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.betManegerGroupBox = new System.Windows.Forms.GroupBox();
            this.betGuy3Label = new System.Windows.Forms.Label();
            this.betGuy2Label = new System.Windows.Forms.Label();
            this.betGuy1Label = new System.Windows.Forms.Label();
            this.betsLabel = new System.Windows.Forms.Label();
            this.raceButton = new System.Windows.Forms.Button();
            this.grayhoundNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.sentenceLabel = new System.Windows.Forms.Label();
            this.betAmountNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.makeBetButton = new System.Windows.Forms.Button();
            this.selectedGuyLabel = new System.Windows.Forms.Label();
            this.guy3RadioButton = new System.Windows.Forms.RadioButton();
            this.guy2RadioButton = new System.Windows.Forms.RadioButton();
            this.guy1RadioButton = new System.Windows.Forms.RadioButton();
            this.minimumBetLabel = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.grayhound1PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayhound2PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayhound3PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayhound4PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.betManegerGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grayhoundNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.betAmountNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // grayhound1PictureBox
            // 
            this.grayhound1PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("grayhound1PictureBox.Image")));
            this.grayhound1PictureBox.Location = new System.Drawing.Point(48, 24);
            this.grayhound1PictureBox.Name = "grayhound1PictureBox";
            this.grayhound1PictureBox.Size = new System.Drawing.Size(75, 20);
            this.grayhound1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grayhound1PictureBox.TabIndex = 1;
            this.grayhound1PictureBox.TabStop = false;
            // 
            // grayhound2PictureBox
            // 
            this.grayhound2PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("grayhound2PictureBox.Image")));
            this.grayhound2PictureBox.Location = new System.Drawing.Point(48, 73);
            this.grayhound2PictureBox.Name = "grayhound2PictureBox";
            this.grayhound2PictureBox.Size = new System.Drawing.Size(75, 20);
            this.grayhound2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grayhound2PictureBox.TabIndex = 6;
            this.grayhound2PictureBox.TabStop = false;
            // 
            // grayhound3PictureBox
            // 
            this.grayhound3PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("grayhound3PictureBox.Image")));
            this.grayhound3PictureBox.Location = new System.Drawing.Point(48, 140);
            this.grayhound3PictureBox.Name = "grayhound3PictureBox";
            this.grayhound3PictureBox.Size = new System.Drawing.Size(75, 20);
            this.grayhound3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grayhound3PictureBox.TabIndex = 7;
            this.grayhound3PictureBox.TabStop = false;
            // 
            // grayhound4PictureBox
            // 
            this.grayhound4PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("grayhound4PictureBox.Image")));
            this.grayhound4PictureBox.Location = new System.Drawing.Point(48, 196);
            this.grayhound4PictureBox.Name = "grayhound4PictureBox";
            this.grayhound4PictureBox.Size = new System.Drawing.Size(75, 20);
            this.grayhound4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grayhound4PictureBox.TabIndex = 8;
            this.grayhound4PictureBox.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(776, 228);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // betManegerGroupBox
            // 
            this.betManegerGroupBox.Controls.Add(this.betGuy3Label);
            this.betManegerGroupBox.Controls.Add(this.betGuy2Label);
            this.betManegerGroupBox.Controls.Add(this.betGuy1Label);
            this.betManegerGroupBox.Controls.Add(this.betsLabel);
            this.betManegerGroupBox.Controls.Add(this.raceButton);
            this.betManegerGroupBox.Controls.Add(this.grayhoundNumericUpDown);
            this.betManegerGroupBox.Controls.Add(this.sentenceLabel);
            this.betManegerGroupBox.Controls.Add(this.betAmountNumericUpDown);
            this.betManegerGroupBox.Controls.Add(this.makeBetButton);
            this.betManegerGroupBox.Controls.Add(this.selectedGuyLabel);
            this.betManegerGroupBox.Controls.Add(this.guy3RadioButton);
            this.betManegerGroupBox.Controls.Add(this.guy2RadioButton);
            this.betManegerGroupBox.Controls.Add(this.guy1RadioButton);
            this.betManegerGroupBox.Controls.Add(this.minimumBetLabel);
            this.betManegerGroupBox.Location = new System.Drawing.Point(12, 247);
            this.betManegerGroupBox.Name = "betManegerGroupBox";
            this.betManegerGroupBox.Size = new System.Drawing.Size(776, 148);
            this.betManegerGroupBox.TabIndex = 10;
            this.betManegerGroupBox.TabStop = false;
            this.betManegerGroupBox.Text = "Weddenschap Maneger";
            // 
            // betGuy3Label
            // 
            this.betGuy3Label.AutoSize = true;
            this.betGuy3Label.Location = new System.Drawing.Point(455, 89);
            this.betGuy3Label.Name = "betGuy3Label";
            this.betGuy3Label.Size = new System.Drawing.Size(58, 13);
            this.betGuy3Label.TabIndex = 13;
            this.betGuy3Label.Text = "inzet guy 3";
            // 
            // betGuy2Label
            // 
            this.betGuy2Label.AutoSize = true;
            this.betGuy2Label.Location = new System.Drawing.Point(455, 66);
            this.betGuy2Label.Name = "betGuy2Label";
            this.betGuy2Label.Size = new System.Drawing.Size(58, 13);
            this.betGuy2Label.TabIndex = 12;
            this.betGuy2Label.Text = "inzet guy 2";
            // 
            // betGuy1Label
            // 
            this.betGuy1Label.AutoSize = true;
            this.betGuy1Label.Location = new System.Drawing.Point(455, 43);
            this.betGuy1Label.Name = "betGuy1Label";
            this.betGuy1Label.Size = new System.Drawing.Size(58, 13);
            this.betGuy1Label.TabIndex = 11;
            this.betGuy1Label.Text = "inzet guy 1";
            // 
            // betsLabel
            // 
            this.betsLabel.AutoSize = true;
            this.betsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.betsLabel.Location = new System.Drawing.Point(452, 20);
            this.betsLabel.Name = "betsLabel";
            this.betsLabel.Size = new System.Drawing.Size(53, 13);
            this.betsLabel.TabIndex = 10;
            this.betsLabel.Text = "Inzetten";
            // 
            // raceButton
            // 
            this.raceButton.Location = new System.Drawing.Point(455, 113);
            this.raceButton.Name = "raceButton";
            this.raceButton.Size = new System.Drawing.Size(315, 23);
            this.raceButton.TabIndex = 9;
            this.raceButton.Text = "Race!";
            this.raceButton.UseVisualStyleBackColor = true;
            this.raceButton.Click += new System.EventHandler(this.raceButton_Click);
            // 
            // grayhoundNumericUpDown
            // 
            this.grayhoundNumericUpDown.Location = new System.Drawing.Point(263, 116);
            this.grayhoundNumericUpDown.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.grayhoundNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.grayhoundNumericUpDown.Name = "grayhoundNumericUpDown";
            this.grayhoundNumericUpDown.Size = new System.Drawing.Size(60, 20);
            this.grayhoundNumericUpDown.TabIndex = 8;
            this.grayhoundNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // sentenceLabel
            // 
            this.sentenceLabel.AutoSize = true;
            this.sentenceLabel.Location = new System.Drawing.Point(145, 118);
            this.sentenceLabel.Name = "sentenceLabel";
            this.sentenceLabel.Size = new System.Drawing.Size(112, 13);
            this.sentenceLabel.TabIndex = 7;
            this.sentenceLabel.Text = "geld op hond nummer:";
            // 
            // betAmountNumericUpDown
            // 
            this.betAmountNumericUpDown.Location = new System.Drawing.Point(79, 116);
            this.betAmountNumericUpDown.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.betAmountNumericUpDown.Name = "betAmountNumericUpDown";
            this.betAmountNumericUpDown.Size = new System.Drawing.Size(60, 20);
            this.betAmountNumericUpDown.TabIndex = 6;
            this.betAmountNumericUpDown.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // makeBetButton
            // 
            this.makeBetButton.Enabled = false;
            this.makeBetButton.Location = new System.Drawing.Point(329, 113);
            this.makeBetButton.Name = "makeBetButton";
            this.makeBetButton.Size = new System.Drawing.Size(120, 23);
            this.makeBetButton.TabIndex = 5;
            this.makeBetButton.Text = "Maak Weddenschap";
            this.makeBetButton.UseVisualStyleBackColor = true;
            this.makeBetButton.Click += new System.EventHandler(this.makeBetButton_Click);
            // 
            // selectedGuyLabel
            // 
            this.selectedGuyLabel.AutoSize = true;
            this.selectedGuyLabel.Location = new System.Drawing.Point(6, 118);
            this.selectedGuyLabel.Name = "selectedGuyLabel";
            this.selectedGuyLabel.Size = new System.Drawing.Size(67, 13);
            this.selectedGuyLabel.TabIndex = 4;
            this.selectedGuyLabel.Text = "selected guy";
            // 
            // guy3RadioButton
            // 
            this.guy3RadioButton.AutoSize = true;
            this.guy3RadioButton.Location = new System.Drawing.Point(10, 89);
            this.guy3RadioButton.Name = "guy3RadioButton";
            this.guy3RadioButton.Size = new System.Drawing.Size(107, 17);
            this.guy3RadioButton.TabIndex = 3;
            this.guy3RadioButton.TabStop = true;
            this.guy3RadioButton.Text = "guy3RadioButton";
            this.guy3RadioButton.UseVisualStyleBackColor = true;
            this.guy3RadioButton.CheckedChanged += new System.EventHandler(this.guy1RadioButton_CheckedChanged);
            // 
            // guy2RadioButton
            // 
            this.guy2RadioButton.AutoSize = true;
            this.guy2RadioButton.Location = new System.Drawing.Point(10, 66);
            this.guy2RadioButton.Name = "guy2RadioButton";
            this.guy2RadioButton.Size = new System.Drawing.Size(107, 17);
            this.guy2RadioButton.TabIndex = 2;
            this.guy2RadioButton.TabStop = true;
            this.guy2RadioButton.Text = "guy2RadioButton";
            this.guy2RadioButton.UseVisualStyleBackColor = true;
            this.guy2RadioButton.CheckedChanged += new System.EventHandler(this.guy1RadioButton_CheckedChanged);
            // 
            // guy1RadioButton
            // 
            this.guy1RadioButton.AutoSize = true;
            this.guy1RadioButton.Location = new System.Drawing.Point(10, 43);
            this.guy1RadioButton.Name = "guy1RadioButton";
            this.guy1RadioButton.Size = new System.Drawing.Size(107, 17);
            this.guy1RadioButton.TabIndex = 1;
            this.guy1RadioButton.TabStop = true;
            this.guy1RadioButton.Text = "guy1RadioButton";
            this.guy1RadioButton.UseVisualStyleBackColor = true;
            this.guy1RadioButton.CheckedChanged += new System.EventHandler(this.guy1RadioButton_CheckedChanged);
            // 
            // minimumBetLabel
            // 
            this.minimumBetLabel.AutoSize = true;
            this.minimumBetLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimumBetLabel.Location = new System.Drawing.Point(7, 20);
            this.minimumBetLabel.Name = "minimumBetLabel";
            this.minimumBetLabel.Size = new System.Drawing.Size(130, 13);
            this.minimumBetLabel.TabIndex = 0;
            this.minimumBetLabel.Text = "Minimale inzet: 5 geld";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 401);
            this.Controls.Add(this.betManegerGroupBox);
            this.Controls.Add(this.grayhound4PictureBox);
            this.Controls.Add(this.grayhound3PictureBox);
            this.Controls.Add(this.grayhound1PictureBox);
            this.Controls.Add(this.grayhound2PictureBox);
            this.Controls.Add(this.pictureBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grayhound1PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayhound2PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayhound3PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayhound4PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.betManegerGroupBox.ResumeLayout(false);
            this.betManegerGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grayhoundNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.betAmountNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox grayhound1PictureBox;
        private System.Windows.Forms.PictureBox grayhound2PictureBox;
        private System.Windows.Forms.PictureBox grayhound3PictureBox;
        private System.Windows.Forms.PictureBox grayhound4PictureBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox betManegerGroupBox;
        private System.Windows.Forms.Label betGuy3Label;
        private System.Windows.Forms.Label betGuy2Label;
        private System.Windows.Forms.Label betGuy1Label;
        private System.Windows.Forms.Label betsLabel;
        private System.Windows.Forms.Button raceButton;
        private System.Windows.Forms.NumericUpDown grayhoundNumericUpDown;
        private System.Windows.Forms.Label sentenceLabel;
        private System.Windows.Forms.NumericUpDown betAmountNumericUpDown;
        private System.Windows.Forms.Button makeBetButton;
        private System.Windows.Forms.Label selectedGuyLabel;
        private System.Windows.Forms.RadioButton guy3RadioButton;
        private System.Windows.Forms.RadioButton guy2RadioButton;
        private System.Windows.Forms.RadioButton guy1RadioButton;
        private System.Windows.Forms.Label minimumBetLabel;
        private System.Windows.Forms.Timer timer1;
    }
}

