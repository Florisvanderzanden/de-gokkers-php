﻿namespace racetest
{
    public class Bet
    {
        public int Amount;
        public int Grayhound;

        public Bet( int aamount, int adog)
        {
            this.Amount = aamount;
            this.Grayhound = adog;
        }
    }
}