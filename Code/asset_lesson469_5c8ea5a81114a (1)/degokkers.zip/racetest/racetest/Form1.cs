﻿using System;
using System.Windows.Forms;

namespace racetest
{
    public partial class Form1 : Form
    {
        //maakt grayhound & guy array aan
        Grayhound[] Grayhounds = new Grayhound[4];
        Guy[] Guys = new Guy[3];
        //maakt een random instance aan
        Random generalRandomizer = new Random();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //maakt 4 grayhounds aan
            Grayhounds[0] = new Grayhound(grayhound1PictureBox, generalRandomizer);
            Grayhounds[1] = new Grayhound(grayhound2PictureBox, generalRandomizer);
            Grayhounds[2] = new Grayhound(grayhound3PictureBox, generalRandomizer);
            Grayhounds[3] = new Grayhound(grayhound4PictureBox, generalRandomizer);

            //maakt 3 guys aan
            Guys[0] = new Guy(guy1RadioButton, betGuy1Label, "Jantje", 25);
            Guys[1] = new Guy(guy2RadioButton, betGuy2Label, "Pietje", 25);
            Guys[2] = new Guy(guy3RadioButton, betGuy3Label, "Floris", 25);

            //geeft elke grayhound startlocatie en tracklength
            for (int i = 0; i < 4; i++)
            {
                Grayhounds[i].TakeStartingPositions(48, 655);
            }

            for ( int i = 0; i < 3; i++)
            {
                Guys[i].UpdatesLabels();
            }
        }

        private void guy1RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            selectedGuyLabel.Text = SelectedGuy().Name;
            makeBetButton.Enabled = true;
        }

        private void makeBetButton_Click(object sender, EventArgs e)
        {
            if (SelectedGuy().PlaceBet(betAmountNumericUpDown.Value, grayhoundNumericUpDown.Value)){
                //bet gemaakt
            }
            else
            {
                MessageBox.Show("Niet genoeg geld");
            }
        }

        private Guy SelectedGuy()
        {
            if (guy1RadioButton.Checked)
            {
                return Guys[0];
            }
            else if (guy2RadioButton.Checked)
            {
                return Guys[1];
            }
            else if (guy3RadioButton.Checked)
            {
                return Guys[2];
            }
            else
            {
                return null;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //laat grayhounds rennen en returnt welke heeft gewonnen
            for (int i = 0; i < 4; i++)
            {
                if (Grayhounds[i].Run())
                {
                    timer1.Stop();
                    MessageBox.Show(String.Format("hond {0} heeft Gewonnen", i + 1));
                    betManegerGroupBox.Enabled = true;
                    //clearbet voor elke guy
                    for(int j = 0; j < Guys.Length; j++)
                    {
                        Guys[j].ClearBet(i + 1);
                    }
                    backToStart();
                }
            }
        }

        private void raceButton_Click(object sender, EventArgs e)
        {
            betManegerGroupBox.Enabled = false;
            backToStart();
            timer1.Start();
        }

        private void backToStart()
        {
            //resets voor testen, automatisch wanner af
            for (int i = 0; i < 4; i++)
            {
                Grayhounds[i].TakeStartingPositions(48, 655);
            }
        }
    }
}
