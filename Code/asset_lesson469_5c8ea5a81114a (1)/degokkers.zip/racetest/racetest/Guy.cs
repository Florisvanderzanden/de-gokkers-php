﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace racetest
{
    class Guy
    {
        public string Name = "";
        public Bet MyBet = null;
        private decimal Cash = 0;
        private RadioButton MyRadioButton;
        private Label MyLabel;

        public Guy (RadioButton aradiobutton, Label alabel, string aname, int acash)
        {
            this.MyRadioButton = aradiobutton;
            this.MyLabel = alabel;
            this.Name = aname;
            this.Cash = acash;
        }

        public void UpdatesLabels()
        {
            if( this.MyBet == null)
            {
                this.MyLabel.Text = string.Format("{0} heeft nog niks ingezet", this.Name);
            }
            else
            {
                this.MyLabel.Text = string.Format("{0} heeft {1} ingezet op hond {2}", this.Name, this.MyBet.Amount, this.MyBet.Grayhound);
            }
            this.MyRadioButton.Text = string.Format("{0} heeft {1} geld", this.Name, this.Cash);
        }

        public void ClearBet(int winningDog)
        {
            if( MyBet != null)
            {
                if(MyBet.Grayhound == winningDog)
                {
                    this.Cash += MyBet.Amount * 2;
                }
            }
            this.MyBet = null;
            UpdatesLabels();
        }

        public bool PlaceBet(decimal aamount, decimal adog)
        {
            if( aamount <= this.Cash)
            {
                this.MyBet = new Bet(Decimal.ToInt32(aamount), Decimal.ToInt32(adog));
                this.Cash -= aamount;
                this.UpdatesLabels();
                return true;
            }
            else{
                return false;
            }
        }
    }
}
