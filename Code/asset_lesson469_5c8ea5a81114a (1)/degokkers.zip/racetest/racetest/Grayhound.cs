﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace racetest
{
    class Grayhound
    {
        private int RacetrackLength = 0;
        private PictureBox MyPictureBox = null;
        private int Location
        {
            get
            {
                return MyPictureBox.Location.X;
            }
            set
            {
                // Updates X locatie van MyPictureBox
                Point P = MyPictureBox.Location;
                P.X = value;
                MyPictureBox.Location = P;
            }
        }
        private Random Randomizer;

        public Grayhound(PictureBox apicturebox, Random arandomizer)
        {
            //geeft MyPictureBox & Randomizer een waarde
            this.MyPictureBox = apicturebox;
            this.Randomizer = arandomizer;
        }
        public bool Run()
        {
            // zet ofwel 1, 2, 3 of 4 random stappen vooruit
            int distance = Randomizer.Next(1, 5);
            // Update de positie van deze grayhound
            Location += distance * 10;
            // Return true als de race heeft gewonnen
            return Location >= RacetrackLength;
        }
        public void TakeStartingPositions(int aposition, int atrackLength)
        {
            //update racetracklength & loctie
            RacetrackLength = atrackLength;
            Location = aposition;
        }
    }
}
